
// System
	const VisChangeEventName = document.webkitHidden ? 'webkitvisibilitychange' : 'visibilitychange';
	const reportAndRethrow = note => err => {
		console.error('%s\n%s', (note || 'Error:'), err);
		throw err;
	};
	const sleep = ms => res => new Promise(resolve => setTimeout(() => resolve(res), ms));
	const bindHandlers = (obj, proto) => {
		if(proto === undefined) proto = Object.getPrototypeOf(obj);
		if(proto === null) return obj;
		bindHandlers(obj, Object.getPrototypeOf(proto));
		Object.getOwnPropertyNames(proto)
			.filter(prop => /^handle/.test(prop) && typeof obj[prop] === 'function')
			.forEach(prop => obj[prop] = obj[prop].bind(obj));
		return obj;
	};
	const resolveSelector = sel => {
		if(sel === null) return [];
		if(Array.isArray(sel)) return sel;
		if(typeof sel === 'string') return [...document.querySelectorAll(sel)];
		return [sel];
	};
	const waitForSelector = async (sel, interval = 10, timeout = 500) => {
		let t1 = Date.now() + timeout, el;
		do {
			el = document.querySelector(sel);
			if(el !== null) break;
			await sleep(interval)();
		}
		while(el === null && Date.now() < t1);
		return el;
	};
	const remHandler = (sel, events, fn, opts) => {
		events = events.split(/[ ,]/);
		resolveSelector(sel).forEach(elem => events.forEach(event =>
			elem && elem.removeEventListener(event, fn, opts)));
	};
	const addHandler = (sel, events, fn, opts) => {
		events = events.split(/[ ,]/);
		resolveSelector(sel).forEach(elem => events.forEach(event =>
			elem.addEventListener(event, fn, opts)));
	};
	const removeDownEventHandler = (sel, fn, opts) => remHandler(sel, 'mousedown touchstart', fn, opts);
	const addDownEventHandler = (sel, fn, opts) => addHandler(sel, 'mousedown touchstart', fn, opts);
	const removeMoveEventHandler = (sel, fn, opts) => remHandler(sel, 'mousemove touchmove', fn, opts);
	const addMoveEventHandler = (sel, fn, opts) => addHandler(sel, 'mousemove touchmove', fn, opts);
	const removeUpEventHandler = (sel, fn, opts) => remHandler(sel, 'mouseup touchend', fn, opts);
	const addUpEventHandler = (sel, fn, opts) => addHandler(sel, 'mouseup touchend', fn, opts);
	const testLocalStorageQuota = (size) => {
		const STRING100 = [...new Array(100)].map(_=>' ').join('');
		const roughSize = Math.floor(size / STRING100.length);
		const QUOTA_DATA = [...new Array(roughSize)].map(_=>STRING100).join('') + [...new Array(size - roughSize * STRING100.length)].map(_=>' ').join('');
		const key = '___QUOTA_TEST';
		let res = false;
		try {
			for(const lsKey in localStorage) if((lsKey || '').startsWith(key)) localStorage.removeItem(lsKey);
			while(localStorage.getItem(key) !== null) key = key += (Math.random() * 10 | 0);
			localStorage.setItem(key, QUOTA_DATA);
			res = localStorage.getItem(key).length === QUOTA_DATA.length;
		}
		catch(err) {
			Framework.trackError(`testLocalStorageQuota: ${(err||{}).message}`);
		}
		localStorage.removeItem(key);
		return res;
	};
	const findLocalStorageSpace = () => {
		const checkSpace = (min, max) => {
			let mid = Math.round((min + max) * 0.5);
			if(max - mid <= 1) return mid;
			return testLocalStorageQuota(mid)
				? checkSpace(mid, max)
				: checkSpace(min, mid);
		};
		return checkSpace(0, 10e6);
	};
	const formatHHMMSS = timeMs => [
			Math.floor(timeMs / 3600000),
			Math.floor(timeMs / 60000) % 60,
			Math.floor(timeMs / 1000) % 60
		]
		.map(t => String(t).padStart(2, '0'))
		.join(':');
	function throttleFunc(func, minDelayMs, maxDelayMs) {
		let minTimeoutId, maxTimeoutId, lastThis, lastArgs;
		function stopFunc() {
			lastThis = undefined; lastArgs = undefined;
			minTimeoutId = clearTimeout(minTimeoutId);
			maxTimeoutId = clearTimeout(maxTimeoutId);
		}
		function handleFunc() {
			let currThis = lastThis, currArgs = lastArgs;
			stopFunc();
			return func.apply(currThis, currArgs);
		}
		function forceFunc(...args) {
			// FIXME: this is broken here
			lastThis = this; lastArgs = args;
			return handleFunc();
		}
		function throttledFunc(...args) {
			lastThis = this; lastArgs = args;
			clearTimeout(minTimeoutId);
			minTimeoutId = setTimeout(handleFunc, minDelayMs);
			if(maxTimeoutId === undefined) maxTimeoutId = setTimeout(handleFunc, maxDelayMs);
		}
		throttledFunc.force = forceFunc;
		throttledFunc.stop = stopFunc;
		return throttledFunc;
	}
	function autoRepeatFunc(func, delayMs, intervalMs) {
		const stopEventNames = `blur focusout pagehide pageshow ${VisChangeEventName} keydown keyup mousedown mouseup touchstart touchend touchcancel`;
		let delayId, intervalId, lastThis, lastArgs;
		function stopFunc(event) {
			if(event && event.repeat) return;
			lastThis = undefined; lastArgs = undefined;
			delayId = clearTimeout(delayId);
			intervalId = clearInterval(intervalId);
			remHandler([window, document], stopEventNames, stopFunc, true);
		}
		function enableStopHandlers() {
			remHandler([window, document], stopEventNames, stopFunc, true);
			addHandler([window, document], stopEventNames, stopFunc, true);
		}
		function handleFunc() {
			return func.apply(lastThis, lastArgs);
		}
		function startRepeat() {
			delayId = clearTimeout(delayId);
			intervalId = setInterval(handleFunc, intervalMs);
			handleFunc();
		}
		function repeatFunc(...args) {
			stopFunc();
			lastThis = this; lastArgs = args;
			delayId = setTimeout(startRepeat, delayMs);
			handleFunc();
			enableStopHandlers();
		}
		repeatFunc.stop = stopFunc;
		return repeatFunc;
	}
	const encodeHTMLEntities = html => html.replace(/[\u00A0-\u9999<>\&]/g, i => '&#'+i.charCodeAt(0)+';');
	function sanitizeHTML(html) {
		html = html.replace(/(r[0-9]+c[0-9]+)([<>])(?=r[0-9]+c[0-9]+)/ig, '$1 $2 ');
		let doc = new DOMParser().parseFromString(html, 'text/html');
		return (doc && doc.body && doc.body.textContent) || '';
	}
	const escapeUrl = url => (new URL(url)).toString();
	const maxLengthLinkText = 500;
	const maxLengthLinkUrl = 50000;
	const reLinkWhitelist = `https:\\/\\/(?:(?:(?:alpha|beta)\\.)?sudokupad\\.app|app\\.crackingthecryptic\\.com)`;
	const makeReMarkdownLink = whitelist => `\\[([^\\]]{1,${maxLengthLinkText}})\\]\\((?=${whitelist})([^)]{1,${maxLengthLinkUrl}})\\)`;
	const reMarkdownLink = new RegExp(makeReMarkdownLink(reLinkWhitelist), 'gm');
	const reMarkdownDomain = new RegExp(reLinkWhitelist, 'gm');
	const locationHost = `${document.location.protocol}//${document.location.host}`
	const linkEnabled = {
		puzzleu: '(?:https?://(?:www\.)?puzzleu\.com)'
	};
	const replaceMarkdownLink = (m, txt, url) => `<a href="${escapeUrl(url)}" class="userlink">${txt}</a>`;
	function parseMarkdownLinks(str) {
		const enabledLink = linkEnabled[getPuzzleId().split('/')[0]];
		str = str
			.replace(reMarkdownLink, replaceMarkdownLink)
			.replace(reMarkdownDomain, locationHost);
		if(enabledLink !== undefined) {
			str = str.replace(new RegExp(makeReMarkdownLink(enabledLink), 'gm'), replaceMarkdownLink);
		}
		return str;
	}
	const mdParse = function parseMd(mdStr) {
		//console.log('parseMd:', mdStr);
		const regs = [
						/*
						[/(?<=(\s|^))[*~]+(?=($|\s))/g, s=>s],
						//[/(?<=[^a-zA-Z0-9*~])[*~]+(?=[^a-zA-Z0-9*~])/g, s=>s],
						[/(?<=[a-zA-Z0-9()])[*~]+(?=[a-zA-Z0-9()])/g, s=>s],
						[/(?<=(?:^|[\n .]))(([*~])(?<!\2\2)\2{0,2})(?!\s)([^*~\n]+)(?<!\s)\1(?!\2)(?=(?:$|[\n .,!?—:;]))/g,
							(m,s) => ({
									'~': `<u>${s}</u>`,
									'~~': `<del>${s}</del>`,
									'*': `<em>${s}</em>`,
									'**': `<strong>${s}</strong>`,
									'***': `<strong><em>${s}</em></strong>`,
								}[m.match(/^(.)\1{0,2}/)[0]])
						],
						*/
					],
					re = /@@@(\d+)@@@/g;
		let str = mdStr, subs = [];
		function getsubs(re, fn) {
			let match, pos = 0, res = [], matchFound = false;
			while((match = re.exec(str)) !== null) {
				const {index: idx, 0: m, 3: a} = match;
				matchFound = true;
				res.push(str.slice(pos, idx), `@@@${subs.length}@@@`);
				subs.push(fn(m,a));
				pos = idx + m.length;
			}
			if(matchFound) {
				res.push(str.slice(pos, str.length));
				str = res.join('');
			}
			return matchFound;
		}
		let cont = true;
		while(cont) {
			cont = false;
			for(const re of regs) cont = cont || getsubs(re[0], re[1]);
		}
		while(re.test(str)) str = str.replace(re, (...m) => subs[m[1]]);
		return str;
	};
	function textToHtml(text) {
		let e = document.createElement('div');
		e.textContent = text;
		let res = e.innerHTML;
		// Added special hyperlink parsing for sudokucon.com URLs in puzzle rules
		try {
			const reLink = /&lt;(https:\/\/sudokucon\.com\/[^\] ]+)&gt;|\[(https:\/\/sudokucon\.com\/[^\] ]+)\]\(([^)]+)\)/g;
			res = res.replaceAll(reLink, (...args) => `<a href="${escapeUrl(args.slice(1, 3).join(''))}" target="_blank" target="_blank" rel="noopener" class="sudokucon-link">${(args[3] || args.slice(1, 3).join(''))}</a>`);
			res = parseMarkdownLinks(res);
			// TODO: format switching
			//res = mdParse(res);
			res = res.replace(/(\\n|\n)/g, '<br />\n');
		}
		catch(err) {
			console.error('textToHtml > invalid URL in text:', {text});
		}
		return res;
	};
	async function fetchWithTimeout(uri, opts = {}) {
		const {timeout = 8000} = opts;
		const controller = new AbortController();
		const id = setTimeout(() => controller.abort(), timeout);
		const response = await fetch(uri, {...opts, signal: controller.signal});
		clearTimeout(id);
		if(response.status !== 200) throw new Error(`fetchWithTimeout response error: ${response.status} / "${response.statusText}"`);
		return response;
	}
	async function sanitizeImageUrl(url, {timeout = 5000} = {}) {
		// Cannot use "no-cors" as that prevents verifying that the link is indeed an image
		const respHead = await fetchWithTimeout(url, {timeout, method: 'HEAD'});
		if(respHead.status !== 200) throw new Error('Unable to fetch image');
		const isImage = /^image\//.test(respHead.headers.get('content-type'));
		if(!isImage) throw new Error('Not a valid image');
		const respGet = await fetchWithTimeout(url, {timeout});
		if(respGet.status !== 200) throw new Error('Unable to fetch image');
		const isGif = /^image\/gif/.test(respHead.headers.get('content-type'));
		let respUrl = URL.createObjectURL(await respGet.blob());
		if(isGif) {
			const img = Object.assign(new Image(), {src: respUrl});
			await img.decode();
			const canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
			canvas.width = img.width;
			canvas.height = img.height;
			ctx.drawImage(img, 0, 0);
			respUrl = URL.createObjectURL(await new Promise(resolve => canvas.toBlob(resolve, 'image/png')));
		}
		return respUrl;
	};
	const svgToTinyDataUri = (() => {
		// Source: https://github.com/tigt/mini-svg-data-uri
		const reWhitespace = /\s+/g,
			reUrlHexPairs = /%[\dA-F]{2}/g,
			hexDecode = {'%20': ' ', '%3D': '=', '%3A': ':', '%2F': '/'},
			specialHexDecode = match => hexDecode[match] || match.toLowerCase(),
			svgToTinyDataUri = svg => {
				svg = String(svg);
				if(svg.charCodeAt(0) === 0xfeff) svg = svg.slice(1);
				svg = svg
					.trim()
					.replace(reWhitespace, ' ')
					.replaceAll('"', '\'');
				svg = encodeURIComponent(svg);
				svg = svg.replace(reUrlHexPairs, specialHexDecode);
				return 'data:image/svg+xml,' + svg;
			};
		svgToTinyDataUri.toSrcset = svg => svgToTinyDataUri(svg).replace(/ /g, '%20');
		return svgToTinyDataUri;
	})();
	function compareObjects(a, b) {
		const {getPrototypeOf, prototype: {toString}} = Object;
		function isEqual(a, b, refs) {
			if(a === b) return true;
			if(a === null || b === null) return false;
			if(refs.indexOf(a) > -1 && refs.indexOf(b) > -1) return true;
			refs.push(a, b);
			const typea = toString.call(a), typeb = toString.call(b);
			if(typea !== typeb) return false;
			const type = typea.slice(8, -1);
			switch(type) {
				case 'Object':
					const keysa = Object.keys(a), keysb = Object.keys(b);
					if(keysa.length !== keysb.length) return false;
					//if(keysa.some(key => !compareObjects(a[key], b[key], refs))) return (console.log('fail: E', a, b), false);
					if(keysa.some(key => {
							let res = compareObjects(a[key], b[key], refs);
							return !res;
						}))
						return false;
					return compareObjects(getPrototypeOf(a), getPrototypeOf(b), refs);
				case 'Array':
					if(a.length !== b.length) return false;
					for(i = 0; i < a.length; i++) {
						if(!(i in a) && !(i in b)) continue; 
						if(i in a !== i in b || !compareObjects(a[i], b[i], refs))
						return false;
					}
					return true;
				case 'Symbol': return a.valueOf() == b.valueOf();
				case 'Date':
				case 'Number':
					return +a == +b || (+a != +a && +b != +b);
				case 'RegExp':
				case 'Function':
				case 'String':
				case 'Boolean':
					return '' + a == '' + b;
				default:
					throw new Error(`Unhandled type: ${type}`);
					return false;
			}
		}
		return isEqual(a, b, []);
	};

// Files
	const loadScript = async (src, sel = 'head', props) => new Promise((onload, onerror) => {
		let elem = resolveSelector(sel)[0]
			.appendChild(Object.assign(
				document.createElement('script'),
				{src, type: 'text/javascript', onload: () => onload(elem), onerror},
				props
			));
		elem.addEventListener('error', onerror);
	});
	const requireScriptDependencies = async urls => Promise.all(urls.filter(url => performance.getEntriesByName(new URL(url, document.location), 'resource').length == 0).map(url => loadScript(url)));
	const attachStylesheet = async (cssText, sel = 'head') => new Promise((onload, onerror) => {
		let elem = resolveSelector(sel)[0].appendChild(Object.assign(
			document.createElement('style'), {textContent: cssText, onload: () => onload(elem), onerror}))
	});
	const downloadBlobAsFile = (blob, filename) => {
		let link = Object.assign(document.createElement('a'),
			{href: window.URL.createObjectURL(blob), download: filename});
		link.dispatchEvent(new MouseEvent('click', {view: window, bubbles: true, cancelable: true}));
		link.remove();
		window.URL.revokeObjectURL(blob);
	};
	const downloadFile = (data, type, filename) => downloadBlobAsFile(new Blob([data], {type}), filename);
	const loadFromFile = (handleFile, opts) => {
		let btn = Object.assign(document.createElement('input'), {type: 'file', visibility: 'hidden'}, opts);
		let handleChange = event => {
			btn.removeEventListener('change', handleChange);
			handleFile(((event.target || {}).files || [])[0]);
		};
		btn.addEventListener('change', handleChange);
		btn.click();
		return btn;
	};
	const readFile = async file => new Promise((resolve, reject) => {
		let reader = new FileReader();
		reader.addEventListener('error', reject);
		reader.addEventListener('load', resolve);
		reader.readAsText(file);
	});
	const zipArchive=k=>{const f=(a,b,...d)=>{const c=new DataView(a.buffer);d.forEach((e,g)=>c.setUint32(b+4*g,e,!0))},n=(a,b,...d)=>{const c=new DataView(a.buffer);d.forEach((e,g)=>c.setUint16(b+2*g,e,!0))},q=(()=>{const a=[];for(var b,d=0;256>d;d++){b=d;for(var c=0;8>c;c++)b=b&1?3988292384^b>>>1:b>>>1;a[d]=b}return a})(),h=[],r=new TextEncoder('utf8');var l=0,p=0;k.forEach(a=>{const b=new Uint8Array(30+a.name.length),d=r.encode(a.name);var c=a.data;for(var e=-1,g=0;g<c.length;g++)e=e>>>8^q[(e^c[g])&255];c=(e^-1)>>>0;f(b,0,67324752);f(b,14,c,a.data.length,a.data.length);n(b,26,a.name.length);b.set(d,30);a.header=b;a.offset=l;h.push(b);h.push(a.data);a.cdr=new Uint8Array(46+a.name.length);f(a.cdr,0,33639248);f(a.cdr,16,c,a.data.length,a.data.length);n(a.cdr,28,a.name.length);f(a.cdr,42,l);a.cdr.set(d,46);p+=a.cdr.length;l+=a.header.length+a.data.length});k.forEach(a=>h.push(a.cdr));const m=new Uint8Array(22);f(m,0,101010256);n(m,8,k.length,k.length);f(m,12,p,l);h.push(m);return new Blob(h,{type:'application/zip'})};

// TODO: Move this into Framework
let SudokuPadUtilities = (() => {
	const ScrollElemEventnames = 'mousedown touchstart mousemove touchmove mouseup touchend';
	const ScrollWindowEventnames = 'mouseup touchend';
	function cancelEventHandler() {
		event.preventDefault();
		event.stopPropagation();
	}
	function makeGrabScrollHandler(elem) {
		let lastPos, hasScrolled = false;
		return function handleGrabScroll(event) {
			const {minDrag} = SudokuPadUtilities;
			let eType = event.type;
			const getPos = e => e.touches ? [e.touches[0].clientX, e.touches[0].clientY] : [e.clientX, e.clientY];
			if(eType === 'mousedown' || eType === 'touchstart') {
				lastPos = getPos(event);
				hasScrolled = false;
			}
			else if((eType === 'mousemove' || eType === 'touchmove') && lastPos) {
				elem = elem || event.target, pos = getPos(event);
				lastPos = lastPos || pos;
				let diff = [(pos[0] - lastPos[0]), (pos[1] - lastPos[1])];
				if(hasScrolled || Math.abs(diff[0]) >= minDrag || Math.abs(diff[1]) >= minDrag) {
					elem.scrollLeft -= diff[0];
					elem.scrollTop -= diff[1];
					lastPos[0] = pos[0];
					lastPos[1] = pos[1];
					hasScrolled = true;
				}
			}
			else if(eType === 'mouseup' || eType === 'touchend') {
				lastPos = undefined;
				if(hasScrolled) {
					event.preventDefault();
					event.stopImmediatePropagation();
					hasScrolled = false;
				}
			}
		};
	}
	function attachScrollHandler(elem, prevHandler) {
		dettachScrollHandler(elem, prevHandler);
		const handler = makeGrabScrollHandler(elem);
		addHandler(elem, ScrollElemEventnames, handler, {capture: true});
		addHandler(window, ScrollWindowEventnames, handler, {capture: true});
		handler.detach = () => dettachScrollHandler(elem, handler);
		return handler;
	}
	function dettachScrollHandler(elem, prevHandler) {
		if(typeof prevHandler === 'function') {
			remHandler(elem, ScrollElemEventnames, prevHandler, {capture: true});
			remHandler(window, ScrollWindowEventnames, prevHandler, {capture: true});
		}
	}
	return {
		minDrag: 5,
		cancelEventHandler,
		makeGrabScrollHandler,
		attachScrollHandler,
		dettachScrollHandler
	};
})();

// Fullscreen
	let docEl = document.documentElement, reqFs = docEl.requestFullscreen || docEl.webkitRequestFullscreen || docEl.mozRequestFullScreen || docEl.msRequestFullscreen;
	let doc = document, exitFs = doc.exitFullscreen || doc.webkitExitFullscreen || doc.mozCancelFullScreen || doc.msExitFullscreen;
	const isFullscreen = () => document.fullscreenElement != null;
	const requestFullscreen = (el) => (typeof reqFs === 'function') ? Promise.resolve(reqFs.call(el || docEl)) : Promise.reject('Fullscreen API is not supported.');
	const exitFullscreen = () => (typeof exitFs === 'function') ? Promise.resolve(exitFs.call(doc)) : Promise.reject('Fullscreen API is not supported.');
	const toggleFullscreen = (el) => isFullscreen() ? exitFullscreen() : requestFullscreen(el || docEl);

// SVG Tools
	const $ = selector => document.querySelector(selector);
	const bounds = elem => {
		if(typeof elem === 'string') elem = $(elem);
		return elem.getBoundingClientRect();
	};
	const scaleToFit = (content, container, margins = {}) => {
		var containerWidth = container.width - (margins.h || 0);
		var containerHeight = container.height - (margins.v || 0);
		var xRatio = containerWidth / content.width;
		var yRatio = containerHeight / content.height;
		var scale = (content.height * xRatio > containerHeight) ? yRatio : xRatio;
		return scale;
	};
	const getTransform = elem => {
		if(typeof elem === 'string') elem = document.querySelector(elem);
		let res = {elem};
		let computedStyle = window.getComputedStyle(elem, null);
		let transform = ((computedStyle.transform.match(/matrix\((.*?)\)/i) || [])[1] || '').split(/\s*,\s*/).map(parseFloat);
		'sx,b,c,sy,tx,ty'.split(',').forEach((prop, i) => res[prop] = transform[i]);
		'left,top,width,height'.split(',').forEach((prop, i) => res[prop] = parseFloat(computedStyle[prop]));
		return res;
	};

// Numbers
	const triangularNumber = value => {
		let abs = Math.abs(value);
		return ((abs / 2) * (abs + 1)) * (abs / value) || 0;
	};

// CSS
	const cssColorHasAlpha = col => /^\s*(#....(....)?|rgba|transparent)\s*$/.test(col);

// Geometry
	const calcDistance = (a, b) => {
		const ax = (a.x !== undefined) ? a.x : a[0], ay = (a.y !== undefined) ? a.y : a[1];
		const bx = (b.x !== undefined) ? b.x : b[0], by = (b.y !== undefined) ? b.y : b[1];
		const dx = bx - ax, dy = by - ay;
		return Math.sqrt(dx * dx + dy * dy);
	};
	const calcDistanceArr = (a, b) => { const dx = b[0] - a[0], dy = b[1] - a[1]; return Math.sqrt(dx * dx + dy * dy); };
	const pathLength = points => {
		var len = 0;
		(points || []).forEach((p, idx, arr) => len += (idx > 0) ? calcDistance(arr[idx - 1], p) : 0);
		return len;
	};
	const calcAngle = (a1, a2, b1, b2) => {
		const dax = a2[0] - a1[0], day = a2[1] - a1[1];
		const dbx = b2[0] - b1[0], dby = b2[1] - b1[1];
		var angle = Math.atan2(dax * dby - day * dbx, dax * dbx + day * dby);
		if(angle < 0) angle = angle * -1;
		return angle * (180 / Math.PI);
	};
	const squareSegment = (a1, a2) => {
		const angToSquareEdgePoint = a => {
			let phi = a * Math.PI / 180;
			let sin = Math.sin(phi), cos = Math.cos(phi + Math.PI);
			let x, y;
			if(Math.abs(sin) < Math.abs(cos)) {
				y = Math.sign(cos);
				x = Math.tan(phi) * -y;
			}
			else {
				x = Math.sign(sin);
				y = (1 / Math.tan(phi)) * -x;
			}
			return [0.5 * (x + 1), 0.5 * (y + 1)];
		};
		let da = a2 - a1;
		let offset = a1 - (a1 % 90);
		let b1 = a1 % 90, b2 = b1 + da;
		let ps = [];
		ps.push(angToSquareEdgePoint(b1 + offset));
		for(let c = 0; c < 4; c++) {
			let ca = 45 + c * 90;
			if(Math.sign(b1 - ca) !== Math.sign(b2 - ca)) ps.push(angToSquareEdgePoint(ca + offset));
		}
		ps.push(angToSquareEdgePoint(b2 + offset));
		return ps;
	};
	const toRC = ([r, c]) => ([Math.floor(r), Math.floor(c)]);
	const isSameRC = (rc1 = [], rc2 = []) => rc1[0] === rc2[0] && rc1[1] === rc2[1];
	const roundCenter = ([r, c]) => ([Math.floor(r) + 0.5, Math.floor(c) + 0.5]);
	const getLinePoints = (x0, y0, x1, y1, points = []) => {
		const dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0),
					sx = (x0 < x1) ? 1 : -1, sy = (y0 < y1) ? 1 : -1,
					maxSteps = Math.max(dx, dy) + 1;
		let err = dx - dy, steps = 0;
		while(steps++ < maxSteps) {
			points.push([x0, y0]);
			if((x0 === x1) && (y0 === y1)) break;
			let e2 = 2*err;
			if(e2 > -dy) { err -= dy; x0  += sx; }
			if(e2 < dx) { err += dx; y0  += sy; }
		}
		return points;
	};
	const stepPoints = (x0, y0, x1, y1, handler) => {
		const dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0),
					sx = (x0 < x1) ? 1 : -1, sy = (y0 < y1) ? 1 : -1,
					maxSteps = Math.max(dx, dy) + 1;
		let err = dx - dy, steps = 0;
		while(steps++ < maxSteps) {
			handler(x0, y0);
			if((x0 === x1) && (y0 === y1)) break;
			let e2 = 2*err;
			if(e2 > -dy) { err -= dy; x0  += sx; }
			if(e2 < dx) { err += dx; y0  += sy; }
		}
	};
	const getCellsAlongPoints = points => {
		const cells = [], rcs = points.map(toRC)
		for(let i = 0, len = rcs.length - 1; i < len; i++) {
			cells.push(...getLinePoints(...rcs[i], ...rcs[i + 1]).map(rc => rc.join(':')));
		}
		return [...new Set(cells)].map(rc => rc.split(':').map(n => parseInt(n)));
	};

// Checksum
	const md5Digest = ((data) => {
		function md5cycle(x, k) {
			var a = x[0], b = x[1], c = x[2], d = x[3];

			a = ff(a, b, c, d, k[0], 7, -680876936);
			d = ff(d, a, b, c, k[1], 12, -389564586);
			c = ff(c, d, a, b, k[2], 17,  606105819);
			b = ff(b, c, d, a, k[3], 22, -1044525330);
			a = ff(a, b, c, d, k[4], 7, -176418897);
			d = ff(d, a, b, c, k[5], 12,  1200080426);
			c = ff(c, d, a, b, k[6], 17, -1473231341);
			b = ff(b, c, d, a, k[7], 22, -45705983);
			a = ff(a, b, c, d, k[8], 7,  1770035416);
			d = ff(d, a, b, c, k[9], 12, -1958414417);
			c = ff(c, d, a, b, k[10], 17, -42063);
			b = ff(b, c, d, a, k[11], 22, -1990404162);
			a = ff(a, b, c, d, k[12], 7,  1804603682);
			d = ff(d, a, b, c, k[13], 12, -40341101);
			c = ff(c, d, a, b, k[14], 17, -1502002290);
			b = ff(b, c, d, a, k[15], 22,  1236535329);

			a = gg(a, b, c, d, k[1], 5, -165796510);
			d = gg(d, a, b, c, k[6], 9, -1069501632);
			c = gg(c, d, a, b, k[11], 14,  643717713);
			b = gg(b, c, d, a, k[0], 20, -373897302);
			a = gg(a, b, c, d, k[5], 5, -701558691);
			d = gg(d, a, b, c, k[10], 9,  38016083);
			c = gg(c, d, a, b, k[15], 14, -660478335);
			b = gg(b, c, d, a, k[4], 20, -405537848);
			a = gg(a, b, c, d, k[9], 5,  568446438);
			d = gg(d, a, b, c, k[14], 9, -1019803690);
			c = gg(c, d, a, b, k[3], 14, -187363961);
			b = gg(b, c, d, a, k[8], 20,  1163531501);
			a = gg(a, b, c, d, k[13], 5, -1444681467);
			d = gg(d, a, b, c, k[2], 9, -51403784);
			c = gg(c, d, a, b, k[7], 14,  1735328473);
			b = gg(b, c, d, a, k[12], 20, -1926607734);

			a = hh(a, b, c, d, k[5], 4, -378558);
			d = hh(d, a, b, c, k[8], 11, -2022574463);
			c = hh(c, d, a, b, k[11], 16,  1839030562);
			b = hh(b, c, d, a, k[14], 23, -35309556);
			a = hh(a, b, c, d, k[1], 4, -1530992060);
			d = hh(d, a, b, c, k[4], 11,  1272893353);
			c = hh(c, d, a, b, k[7], 16, -155497632);
			b = hh(b, c, d, a, k[10], 23, -1094730640);
			a = hh(a, b, c, d, k[13], 4,  681279174);
			d = hh(d, a, b, c, k[0], 11, -358537222);
			c = hh(c, d, a, b, k[3], 16, -722521979);
			b = hh(b, c, d, a, k[6], 23,  76029189);
			a = hh(a, b, c, d, k[9], 4, -640364487);
			d = hh(d, a, b, c, k[12], 11, -421815835);
			c = hh(c, d, a, b, k[15], 16,  530742520);
			b = hh(b, c, d, a, k[2], 23, -995338651);

			a = ii(a, b, c, d, k[0], 6, -198630844);
			d = ii(d, a, b, c, k[7], 10,  1126891415);
			c = ii(c, d, a, b, k[14], 15, -1416354905);
			b = ii(b, c, d, a, k[5], 21, -57434055);
			a = ii(a, b, c, d, k[12], 6,  1700485571);
			d = ii(d, a, b, c, k[3], 10, -1894986606);
			c = ii(c, d, a, b, k[10], 15, -1051523);
			b = ii(b, c, d, a, k[1], 21, -2054922799);
			a = ii(a, b, c, d, k[8], 6,  1873313359);
			d = ii(d, a, b, c, k[15], 10, -30611744);
			c = ii(c, d, a, b, k[6], 15, -1560198380);
			b = ii(b, c, d, a, k[13], 21,  1309151649);
			a = ii(a, b, c, d, k[4], 6, -145523070);
			d = ii(d, a, b, c, k[11], 10, -1120210379);
			c = ii(c, d, a, b, k[2], 15,  718787259);
			b = ii(b, c, d, a, k[9], 21, -343485551);

			x[0] = add32(a, x[0]);
			x[1] = add32(b, x[1]);
			x[2] = add32(c, x[2]);
			x[3] = add32(d, x[3]);
		}
		function cmn(q, a, b, x, s, t) {
			a = add32(add32(a, q), add32(x, t));
			return add32((a << s) | (a >>> (32 - s)), b);
		}
		function ff(a, b, c, d, x, s, t) {
			return cmn((b & c) | ((~b) & d), a, b, x, s, t);
		}
		function gg(a, b, c, d, x, s, t) {
			return cmn((b & d) | (c & (~d)), a, b, x, s, t);
		}
		function hh(a, b, c, d, x, s, t) {
			return cmn(b ^ c ^ d, a, b, x, s, t);
		}
		function ii(a, b, c, d, x, s, t) {
			return cmn(c ^ (b | (~d)), a, b, x, s, t);
		}
		function md51(s) {
			var txt = '';
			var n = s.length,
			state = [1732584193, -271733879, -1732584194, 271733878], i;
			for (i=64; i<=s.length; i+=64) {
			md5cycle(state, md5blk(s.substring(i-64, i)));
			}
			s = s.substring(i-64);
			var tail = [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0];
			for (i=0; i<s.length; i++)
			tail[i>>2] |= s.charCodeAt(i) << ((i%4) << 3);
			tail[i>>2] |= 0x80 << ((i%4) << 3);
			if (i > 55) {
			md5cycle(state, tail);
			for (i=0; i<16; i++) tail[i] = 0;
			}
			tail[14] = n*8;
			md5cycle(state, tail);
			return state;
		}
		function md5blk(s) {
			var md5blks = [], i;
			for (i=0; i<64; i+=4) {
			md5blks[i>>2] = s.charCodeAt(i)
			+ (s.charCodeAt(i+1) << 8)
			+ (s.charCodeAt(i+2) << 16)
			+ (s.charCodeAt(i+3) << 24);
			}
			return md5blks;
		}
		var hex_chr = '0123456789abcdef'.split('');
		function rhex(n) {
			var s='', j=0;
			for(; j<4; j++)
			s += hex_chr[(n >> (j * 8 + 4)) & 0x0F]
			+ hex_chr[(n >> (j * 8)) & 0x0F];
			return s;
		}
		function hex(x) {
			for (var i=0; i<x.length; i++)
			x[i] = rhex(x[i]);
			return x.join('');
		}
		function md5(s) {
			return hex(md51(s));
		}
		function add32(a, b) {
			return (a + b) & 0xFFFFFFFF;
		}
		if(md5('hello') != '5d41402abc4b2a76b9719d911017c592') {
			function add32(x, y) {
				var lsw = (x & 0xFFFF) + (y & 0xFFFF),
				msw = (x >> 16) + (y >> 16) + (lsw >> 16);
				return (msw << 16) | (lsw & 0xFFFF);
			}
		}
		return md5;
	})();

// Hide Solution
	const HideSol = (() => {
		const HS = {
			radix: 5,
			base: 32,
		};
		const solMap = sol => sol.split('').map(d => d.match(/[?]/) ? '0' : '1').join('');
		const solMapEncode = sol => solMap(sol)
			.padEnd(Math.ceil(sol.length / HS.radix) * HS.radix, '0')
			.match(new RegExp(`(.{${HS.radix}})`,'g'))
			.map(set => parseInt(set, 2).toString(HS.base)).join('');
		const solMapDecode = (map, len) => map
			.split('')
			.map(n => parseInt(n, HS.base).toString(2).padStart(HS.radix, '0'))
			.join('')
			.slice(0, len);
		const mapSol = (sol, map) => sol
			.split('')
			.reduce((acc, cur, idx) => acc + (map[idx] === '1' ? cur : ''), '');
		const hideSol = sol => `${solMapEncode(sol)}|${md5Digest(mapSol(sol, solMap(sol)))}`;
		const checkHiddenSol = (hsol, p81) => {
			const [map, md5] = hsol.split('|');
			let decodedMap = solMapDecode(map, p81.length);
			let p81Mapped = mapSol(p81, decodedMap);
			let digest = md5Digest(p81Mapped);
			return digest === md5;
		};
		HS.solMap = solMap;
		HS.encode = solMapEncode;
		HS.decode = solMapDecode;
		HS.mapSol = mapSol;
		HS.hideSol = hideSol;
		HS.check = checkHiddenSol;
		return HS;
	})();

// JSONEditor
	let createJSONEditor = async (opts = {}) => {
		let url = 'https://cdnjs.cloudflare.com/ajax/libs/jsoneditor/9.5.6/jsoneditor.min.js',
			{json = {}, elem = '#jsoneditor', cssUrl = url.replace('.js', '.css'), jsUrl = url, editor} = opts;
		if(typeof JSONEditor === 'undefined') {
			const promisifyOnload = obj => new Promise((resolve, onerror) => Object.assign(obj, {onload: () => resolve(obj), onerror}));
			let head = document.querySelector('head'),
				link = document.createElement('link'),
				script = document.createElement('script'),
				scriptP = promisifyOnload(script);
			head.appendChild(Object.assign(link, {href: cssUrl, rel: 'stylesheet', type: 'text/css', media: 'all'}));
			head.appendChild(Object.assign(script, {src: jsUrl}));
			await scriptP;
		}
		if(typeof elem === 'string') elem = document.querySelector(elem);
		elem = elem || document.createElement('div');
		if(editor instanceof JSONEditor) editor.destroy();
		editor = new JSONEditor(elem, {});
		editor.set(json);
		return editor;
	};
