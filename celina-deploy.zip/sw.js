const CACHE='celina-puzzle-v48-deploy';
const ASSETS=['./','./index.html','./style.css','./game.js','./play.html','./manifest.json','./favicon.svg','./icon.svg'];
// Proxy SudokuPad API calls to the real upstream so the bundle works from localhost.
const SUDOKUPAD_ORIGIN = 'https://sudokupad.app';

self.addEventListener('install',e=>{
  e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()));
});

self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});

self.addEventListener('message', e => {
  if (e.data && e.data.type === 'SKIP_WAITING') self.skipWaiting();
});

// Network-first for app source (so edits show up without manual cache bumps),
// cache-first for static binary assets (fonts, images, the SudokuPad bundle).
const NET_FIRST = /\.(?:html|css|js|json)(?:\?.*)?$/i;
// SudokuPad bundle filenames have a special char and end with .js — match them as cache-first
const STATIC_FIRST = /\b(sudokupad\.appx|favicon|icon|images|fonts)\b/i;

self.addEventListener('fetch',e=>{
  // Don't touch non-http schemes (chrome-extension://, devtools://, etc.) —
  // attempting to cache them throws TypeError.
  if(!/^https?:$/.test(new URL(e.request.url).protocol)) return;

  const url=new URL(e.request.url);

  // SudokuPad API proxy: when the bundle requests /api/puzzle/<id>, fetch the
  // real puzzle JSON from sudokupad.app and return it. Bypasses CORS because
  // the SW makes the cross-origin call and the page sees a same-origin response.
  if(url.origin===location.origin && url.pathname.startsWith('/api/puzzle/')){
    const upstream=SUDOKUPAD_ORIGIN+url.pathname+url.search;
    e.respondWith(
      fetch(upstream,{credentials:'omit',mode:'cors'}).then(r=>{
        // Re-wrap so the page sees a 200 with the body even if upstream sends weird headers
        return r.text().then(body=>new Response(body,{
          status:r.status,
          headers:{'content-type':r.headers.get('content-type')||'text/plain'}
        }));
      }).catch(err=>new Response('proxy error: '+err.message,{status:502}))
    );
    return;
  }

  // Cross-origin (Google Fonts etc.): stale-while-revalidate
  if(url.origin!==location.origin){
    e.respondWith(
      caches.match(e.request).then(cached=>{
        const fp=fetch(e.request).then(resp=>{
          if(resp&&resp.ok){
            const clone=resp.clone();
            caches.open(CACHE).then(c=>c.put(e.request,clone));
          }
          return resp;
        }).catch(()=>cached);
        return cached||fp;
      })
    );
    return;
  }

  // SudokuPad bundle / images / fonts → cache-first (these don't change)
  if(STATIC_FIRST.test(url.pathname)){
    e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(resp=>{
      const clone=resp.clone();
      caches.open(CACHE).then(c=>c.put(e.request,clone));
      return resp;
    })));
    return;
  }

  // App source (.html/.css/.js/.json) → network-first, fall back to cache offline
  if(NET_FIRST.test(url.pathname) || url.pathname==='/' || url.pathname.endsWith('/')){
    e.respondWith(
      fetch(e.request).then(resp=>{
        if(resp&&resp.ok){
          const clone=resp.clone();
          caches.open(CACHE).then(c=>c.put(e.request,clone));
        }
        return resp;
      }).catch(()=>caches.match(e.request))
    );
    return;
  }

  // Anything else: cache-first
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(resp=>{
    const clone=resp.clone();
    caches.open(CACHE).then(c=>c.put(e.request,clone));
    return resp;
  })));
});
